import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JFrame {
    private static JPanel panelInsert = new JPanel();
    private static JPanel panelCheck = new JPanel();
    private static JButton btnInsert = new JButton("Insert");
    private static JButton btnCheck = new JButton("Check Out");
    int harga,subtotal,total;
    public Menu(){
        new Database();
        setTitle("Menu");
        setSize(500,450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        panelInsert.setLayout(new GridLayout(1, 1));
        panelInsert.setBorder(new EmptyBorder(0, 350, 0, 10));
        btnInsert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String jenis = PesanMenu.jenis.getText();
                int jumlah = Integer.parseInt(PesanMenu.banyak.getValue().toString());
                if(jenis.equals("Ayam Bakar")){
                    harga = 40000;
                }else if(jenis.equals("Sup Ikan")){
                    harga = 30000;
                }else if(jenis.equals("Jus Mangga")){
                    harga = 20000;
                }else if(jenis.equals("Pepsi")){
                    harga = 15000;
                }
                Object[] row ={jenis,jumlah,harga};
                TablePilihMenu.dtm.addRow(row);

                subtotal= jumlah*harga;
                total+=subtotal;

                TotalBayarMenu.total.setText(String.valueOf(total));
            }
        });
        panelInsert.add(btnInsert);

        panelCheck.setLayout(new GridLayout(1, 1));
        panelCheck.setBorder(new EmptyBorder(1, 170, 10, 170));
        btnCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Kwitansi.isiTotalHarga.setText(TotalBayarMenu.total.getText());
                new Kwitansi();
                dispose();
            }
        });
        panelCheck.add(btnCheck);

        add(new TableMenu());
        add(new PesanMenu());
        add(panelInsert);
        add(new TablePilihMenu());
        add(new TotalBayarMenu());
        add(panelCheck);

        setVisible(true);
        setLocationRelativeTo(null);
    }
}