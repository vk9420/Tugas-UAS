import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kwitansi extends JFrame {
    private static JPanel judul = new JPanel();
    private static JPanel totalHarga = new JPanel();
    private static JPanel button = new JPanel();
    static JLabel isiTotalHarga = new JLabel("....................");
    private static JButton btnReservasi = new JButton("Selesai");
    public Kwitansi(){
        new Database();
        setTitle("Form Kwitansi");
        setSize(600,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        judul.setLayout(new GridLayout(1,2));
        judul.add(new JLabel("KWITANSI"));
        judul.setBorder(new EmptyBorder(5, 265, 10, 140));

        totalHarga.setLayout(new GridLayout(3,2));
        totalHarga.add(new JLabel("Total Harga"));
        totalHarga.add(isiTotalHarga);
        totalHarga.setBorder(new EmptyBorder(10, 260, 0, 140));

        button.setBorder(new EmptyBorder(0, 140, 10, 140));
        btnReservasi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        button.add(btnReservasi);

        add(judul);
        add(new PengisianKwitansi());
        add(new TableOrderKwitansi());
        add(totalHarga);
        add(button);

        setVisible(true);
    }
}