import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reservasi extends JFrame {
    private static JPanel button = new JPanel();
    private static JButton btnReservasi = new JButton("Reservasi");
    public Reservasi(){
        new Database();
        setTitle("Form Reservasi");
        setSize(600,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        button.setBorder(new EmptyBorder(1, 125, 10, 140));
        btnReservasi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PengisianKwitansi.IsiTanggalReservasi.setText(PengisianReservasi.Picker.getJFormattedTextField().getText());
                PengisianKwitansi.IsiNama.setText(PengisianReservasi.txtFullName.getText());
                new Menu();
                dispose();
            }
        });
        button.add(btnReservasi);

        add(new TableReservasi());
        add(new PengisianReservasi());
        add(button);

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
