import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TablePilihMenu extends JPanel {
    private static String columnName[]={"Jenis Menu","Banyak Pesanan","Harga"};
    static DefaultTableModel dtm = new DefaultTableModel(null,columnName);
    private static JTable table = new JTable(dtm);
    private static JScrollPane scrollPane = new JScrollPane(table);
    public TablePilihMenu() {
        table.setFillsViewportHeight(true);
        table.setEnabled(false);

        setLayout(new GridLayout(1, 1));
        setBorder(new EmptyBorder(10, 10, 0, 10));

        add(scrollPane);
    }
}
