import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class PengisianKwitansi extends JPanel {
    static JLabel IsiTanggalReservasi = new JLabel("....................");
    static JLabel IsiNama = new JLabel("....................");
    public PengisianKwitansi(){
        setLayout(new GridLayout(3,2));

        add(new JLabel("Tanggal Reservasi"));
        add(IsiTanggalReservasi);

        add(new JLabel("Nama"));
        add(IsiNama);

        //Border
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);

        TitledBorder titledBorder = BorderFactory.createTitledBorder(etchedBorder, "");
        titledBorder.setTitleFont(titledBorder.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10,10,0,10), titledBorder));
    }
}
