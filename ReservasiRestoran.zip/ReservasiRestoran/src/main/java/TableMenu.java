import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.Statement;

public class TableMenu extends JPanel {
    private static String columnName[]={"Menu Id","Jenis Menu","Harga"};
    private static DefaultTableModel dtm = new DefaultTableModel(null,columnName);
    private static JTable table = new JTable(dtm);
    private static JScrollPane scrollPane = new JScrollPane(table);
    private static Statement stm;
    private static ResultSet rs;
    public TableMenu(){
        table.setFillsViewportHeight(true);
        table.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                PesanMenu.jenis.setText(dtm.getValueAt(table.getSelectedRow(),1)+"");
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        ShowData();
        setLayout(new GridLayout(1,1));
        setBorder(new EmptyBorder(10, 10, 0, 10));

        add(scrollPane);
    }
    public void ShowData(){
        try{
            String sql = "SELECT * FROM tb_menu";
            stm = Database.db.createStatement();
            rs = stm.executeQuery(sql);
            while(rs.next()){
                Object[] row = {
                        rs.getString("menuID"),
                        rs.getString("jenisMenu"),
                        rs.getInt("harga")
                };
                dtm.addRow(row);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
