import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
    static Connection db;

    public Database(){
        try {
            //load jdbc driver for oracle database
            Class.forName("oracle.jdbc.OracleDriver");

            //establish connection to oracle
            db = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "hr", "oracle");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
