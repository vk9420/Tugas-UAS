import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class PesanMenu extends JPanel {
    static JTextField jenis = new JTextField();
    static JSpinner banyak = new JSpinner();
    public PesanMenu(){
        setLayout(new GridLayout(2, 2));
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        TitledBorder titledBorder = BorderFactory.createTitledBorder(etchedBorder, "Pesanan");
        titledBorder.setTitleFont(titledBorder.getTitleFont().deriveFont(Font.ITALIC));
        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), titledBorder));

        add(new JLabel("Jenis Menu"));
        add(jenis);
        add(new JLabel("Banyak Pesanan"));
        add(banyak);
    }
}
