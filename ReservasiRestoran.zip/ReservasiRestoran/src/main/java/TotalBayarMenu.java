import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class TotalBayarMenu extends JPanel {
    static JTextField total = new JTextField();
    public TotalBayarMenu(){
        setLayout(new GridLayout(1, 2));
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        TitledBorder titledBorder = BorderFactory.createTitledBorder(etchedBorder, "Harga");
        titledBorder.setTitleFont(titledBorder.getTitleFont().deriveFont(Font.ITALIC));
        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), titledBorder));

        add(new JLabel("Total Bayar"));
        add(total);
    }
}
