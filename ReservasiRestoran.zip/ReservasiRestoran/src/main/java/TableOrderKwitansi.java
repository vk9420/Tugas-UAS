import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class TableOrderKwitansi extends JPanel {
    private static JTable table = new JTable(TablePilihMenu.dtm);
    private static JScrollPane scrollPane = new JScrollPane(table);
    public TableOrderKwitansi(){
        table.setFillsViewportHeight(true);
        table.setEnabled(false);

        setLayout(new GridLayout(1,1));
        setBorder(new EmptyBorder(0,10,0,10));

        add(scrollPane);

        //Border
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);

        TitledBorder titledBorder = BorderFactory.createTitledBorder(etchedBorder, "Order : ");
        titledBorder.setTitleFont(titledBorder.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(0,10,0,10), titledBorder));
    }
}
