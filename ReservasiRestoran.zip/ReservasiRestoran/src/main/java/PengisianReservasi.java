import org.jdatepicker.impl.DateComponentFormatter;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.Properties;

public class PengisianReservasi extends JPanel {
    private static UtilDateModel model = new UtilDateModel();
    private static Properties p = new Properties();
    private static JDatePanelImpl Panel = new JDatePanelImpl(model,p);
    static JDatePickerImpl Picker = new JDatePickerImpl(Panel, new DateComponentFormatter());

    static JTextField txtFullName  = new JTextField();
    static JTextField txtMejaID   = new JTextField();
    public PengisianReservasi() {
        setLayout(new GridLayout(3, 2));

        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");

        add(new JLabel("Tanggal Reservasi"));
        add(Picker);

        add(new JLabel("Nama"));
        add(txtFullName);

        add(new JLabel("Meja ID"));
        add(txtMejaID);

        //Border
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);

        TitledBorder titledBorder = BorderFactory.createTitledBorder(etchedBorder, "Pengisian Data Reservasi");
        titledBorder.setTitleFont(titledBorder.getTitleFont().deriveFont(Font.BOLD));

        setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), titledBorder));
    }
}
